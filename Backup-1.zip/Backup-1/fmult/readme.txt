this is IEEE 754 standard Single precision float multiplier
