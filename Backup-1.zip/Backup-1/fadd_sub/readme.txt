This is IEEE 754 floating point single precision (32 bit) adder/subtracter module
